def minha_lib():
    print('Live de python')