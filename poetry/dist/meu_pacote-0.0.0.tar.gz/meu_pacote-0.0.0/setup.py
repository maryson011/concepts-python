from setuptools import setup

setup(
    name='meu_pacote',
    packages=['meu_pacote']
)